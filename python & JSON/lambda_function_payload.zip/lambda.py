def lambda_handler():
    print("test")